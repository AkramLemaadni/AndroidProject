package com.example.gamingstore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class login_pageActivity extends AppCompatActivity {

    EditText userName, passWord;
    Button buttonLogin;

    TextView buttonSignin, text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);

        userName = (EditText)findViewById(R.id.usernameLogin);
        passWord = (EditText)findViewById(R.id.passwordLogin);
        buttonLogin = (Button)findViewById(R.id.loginButton);
        buttonSignin = (TextView)findViewById(R.id.signinButton);




        buttonSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = new Intent(login_pageActivity.this, signin_pageActivity.class);
                    startActivity(intent);
            }
        });

        };
}
