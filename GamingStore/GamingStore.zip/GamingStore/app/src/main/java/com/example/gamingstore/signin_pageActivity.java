package com.example.gamingstore;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class signin_pageActivity extends AppCompatActivity {

    private Button buttonBackLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin_page);

        ImageView myImage = findViewById(R.id.myImage);
        myImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the image click here
                Intent intent = new Intent(signin_pageActivity.this, login_pageActivity.class);
                startActivity(intent);
            }
        });

    }
}

